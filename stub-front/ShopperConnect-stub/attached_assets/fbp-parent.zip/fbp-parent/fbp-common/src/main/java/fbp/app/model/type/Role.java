package fbp.app.model.type;

public enum Role {
    PARENT, USER
}
