package fbp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FbpFamilyBudgetServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(FbpFamilyBudgetServiceApplication.class, args);
    }
}
