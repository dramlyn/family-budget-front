package fbp.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class FbpTransactionServiceApp
{
    public static void main(String[] args) {
        SpringApplication.run(FbpTransactionServiceApp.class, args);
    }
}
