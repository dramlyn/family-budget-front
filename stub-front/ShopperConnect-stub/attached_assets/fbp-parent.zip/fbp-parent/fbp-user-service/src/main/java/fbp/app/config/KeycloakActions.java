package fbp.app.config;

public enum KeycloakActions {
    UPDATE_PASSWORD,
}
